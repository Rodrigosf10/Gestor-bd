<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <?php require_once "procesos/dependencias.php";?>
</head>
<body background="body">
    <div class="container">
        <div class="row mt-5 justify-content-around">
            <div class="col-md-5 mt-4">
                <div class="card border-dark border-rounded" style="width: 28rem;">
                    <img src="img/user.png" class="card-img-top">
                    <div class="card-body text-center">
                        <h1 class="card-title text-center">Usuario</h1>
                        <hr>
                        <p class="card-text" style="text-align:justify">Este apartado permite a los usuarios ya registrados, iniciar sesion a su cuenta de usuario para poder subir, modificar y elimninar archivos que considere importantes y poder clasificarlos por categorias.</p>
                        <a href="login_2.php" class="btn btn-primary text-center border-dark">Iniciar Sesion</a>
                    </div>
                </div>
                <hr>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 mt-4">
                <div class="card border-dark border-rounded" style="width: 28rem;">
                    <img src="img/admin.png" class="card-img-top">
                    <div class="card-body text-center">
                        <h1 class="card-title text-center">Administrador</h1>
                        <hr>
                        <p class="card-text" style="text-align:justify">Este apartado permite al Administrador del lugar, empezar el registro de los usuarios para llevar un mejor control sobre el manejo de las cuentas de usuarios. Solo puede acceder el Administrador.</p>
                        <a href="registro_2.php" class="btn btn-primary text-center border-dark">Acceder</a>
                    </div>
                </div>
                <hr>
            </div>
        </div>
    </div>
</body>
</html>