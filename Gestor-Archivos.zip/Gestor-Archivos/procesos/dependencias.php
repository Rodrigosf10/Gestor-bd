<link rel="stylesheet" type="text/css" href="librerias/b4/b4.min.css">
<link href="librerias/fontawesome/css/all.css" rel="stylesheet">
<link href="librerias/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="librerias/jquery-ui-1.12.1/jquery-ui.theme.css">
<link rel="stylesheet" type="text/css" href="librerias/jquery-ui-1.12.1/jquery-ui.css">


<script src="librerias/b4/jquery-3.6.0.min.js"></script>
<script src="librerias/jquery-ui-1.12.1/jquery-ui.js"></script>
<script src="librerias/b4/bootstrap.min.js"></script>
<script src="librerias/b4/popper.min.js"></script>
<script src="librerias/sweetalert/sweetalert.min.js"></script>
<script src="librerias/datatable/jquery.dataTables.min.js"></script>
<script src="librerias/datatable/dataTables.bootstrap4.min.js"></script>